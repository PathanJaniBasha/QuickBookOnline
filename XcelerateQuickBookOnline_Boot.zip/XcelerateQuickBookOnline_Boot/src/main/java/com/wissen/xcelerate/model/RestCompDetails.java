package com.wissen.xcelerate.model;


import java.io.Serializable;
import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Date;


/**
 * The persistent class for the rest_comp_details database table.
 * 
 */
@Entity
@Table(name="rest_comp_details",schema="common")
//@NamedQuery(name="RestCompDetails.findAll", query="SELECT r FROM RestCompDetails r")
public class RestCompDetails implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="rest_comp_id")
	private int restCompId;

	@Column(name="rest_comp_address")
	private String restCompAddress;

	@Column(name="rest_comp_code")
	private String restCompCode;

	@Column(name="rest_comp_email")
	private String restCompEmail;

	@Column(name="rest_comp_hashcode")
	private String restCompHashcode;

	@Column(name="rest_comp_inactive_date")
	private Timestamp restCompInactiveDate;

	@Column(name="rest_comp_inactive_reason")
	private Timestamp restCompInactiveReason;

	@Column(name="rest_comp_logo")
	private int restCompLogo;

	@Column(name="rest_comp_max_users")
	private int restCompMaxUsers;

	@Column(name="rest_comp_name")
	private String restCompName;

	@Column(name="rest_comp_phone_number1")
	private String restCompPhoneNumber1;

	@Column(name="rest_comp_phone_number2")
	private String restCompPhoneNumber2;

	@Column(name="rest_comp_plan_id")
	private int restCompPlanId;

	@Column(name="rest_comp_registered_date")
	private Timestamp restCompRegisteredDate;

	@Column(name="rest_comp_service_end_date")
	private Timestamp restCompServiceEndDate;

	@Column(name="rest_comp_service_start_date")
	private Timestamp restCompServiceStartDate;

	@Column(name="rest_comp_setup_date")
	private Timestamp restCompSetupDate;

	@Column(name="rest_comp_short_name")
	private String restCompShortName;

	@Column(name="rest_comp_size")
	private String restCompSize;

	@Column(name="rest_comp_status")
	private String restCompStatus;

	@Column(name="rest_comp_title")
	private String restCompTitle;

	@Column(name="schema_name")
	private String schemaName;
	
	@Column(name = "updated_by")
	private Integer updatedBy;

	@Column(name = "updated_datetime")
	private Timestamp updatedDatetime;
	
    private String source;
	
    @Column(name="smtp_email")
    private String smtpEmail;
    
    @Column(name="smtp_auth")
	private String smtpAuth;
    
    @Column(name="encircle_api_token")
    private String encircleApiToken;
     
    @Column(name = "rest_comp_fax_number")
	private String restCompFaxNumber;
	
	@Column(name="rest_comp_website")
	private String restCompWebsite;
	
	@Column(name="rest_comp_url")
    private String restCompUrl;
	// QBO related Columns
	@Column(name="qbo_check")
    private String qboCheck;
	
	@Column(name="qbo_client_id")
    private String qboClientId;
	
	@Column(name="qbo_client_secret")
    private String qboClientSecret;
	
	@Column(name="qbo_realm_id")
    private String qboRealmId;
	
	@Column(name="qbo_start_date")
    private Date qboStartDate;
	
	@Column(name="qbo_verifier_token")
	private String  qboVerifierToken;
	
	@Column(name="qbo_redirect_uri")
	private String  qboRedirectUri;
	@Column(name="qbo_access_token")
	private String  qboAccessToken;
	@Column(name="qbo_refresh_token")
	private String  qboRefreshToken;
	
	public RestCompDetails() {
	}

	public int getRestCompId() {
		return restCompId;
	}

	public void setRestCompId(int restCompId) {
		this.restCompId = restCompId;
	}

	public String getRestCompAddress() {
		return restCompAddress;
	}

	public void setRestCompAddress(String restCompAddress) {
		this.restCompAddress = restCompAddress;
	}

	public String getRestCompCode() {
		return restCompCode;
	}

	public void setRestCompCode(String restCompCode) {
		this.restCompCode = restCompCode;
	}

	public String getRestCompEmail() {
		return restCompEmail;
	}

	public void setRestCompEmail(String restCompEmail) {
		this.restCompEmail = restCompEmail;
	}

	public String getRestCompHashcode() {
		return restCompHashcode;
	}

	public void setRestCompHashcode(String restCompHashcode) {
		this.restCompHashcode = restCompHashcode;
	}

	public Timestamp getRestCompInactiveDate() {
		return restCompInactiveDate;
	}

	public void setRestCompInactiveDate(Timestamp restCompInactiveDate) {
		this.restCompInactiveDate = restCompInactiveDate;
	}

	public Timestamp getRestCompInactiveReason() {
		return restCompInactiveReason;
	}

	public void setRestCompInactiveReason(Timestamp restCompInactiveReason) {
		this.restCompInactiveReason = restCompInactiveReason;
	}

	public int getRestCompLogo() {
		return restCompLogo;
	}

	public void setRestCompLogo(int restCompLogo) {
		this.restCompLogo = restCompLogo;
	}

	public int getRestCompMaxUsers() {
		return restCompMaxUsers;
	}

	public void setRestCompMaxUsers(int restCompMaxUsers) {
		this.restCompMaxUsers = restCompMaxUsers;
	}

	public String getRestCompName() {
		return restCompName;
	}

	public void setRestCompName(String restCompName) {
		this.restCompName = restCompName;
	}

	public String getRestCompPhoneNumber1() {
		return restCompPhoneNumber1;
	}

	public void setRestCompPhoneNumber1(String restCompPhoneNumber1) {
		this.restCompPhoneNumber1 = restCompPhoneNumber1;
	}

	public String getRestCompPhoneNumber2() {
		return restCompPhoneNumber2;
	}

	public void setRestCompPhoneNumber2(String restCompPhoneNumber2) {
		this.restCompPhoneNumber2 = restCompPhoneNumber2;
	}

	public int getRestCompPlanId() {
		return restCompPlanId;
	}

	public void setRestCompPlanId(int restCompPlanId) {
		this.restCompPlanId = restCompPlanId;
	}

	public Timestamp getRestCompRegisteredDate() {
		return restCompRegisteredDate;
	}

	public void setRestCompRegisteredDate(Timestamp restCompRegisteredDate) {
		this.restCompRegisteredDate = restCompRegisteredDate;
	}

	public Timestamp getRestCompServiceEndDate() {
		return restCompServiceEndDate;
	}

	public void setRestCompServiceEndDate(Timestamp restCompServiceEndDate) {
		this.restCompServiceEndDate = restCompServiceEndDate;
	}

	public Timestamp getRestCompServiceStartDate() {
		return restCompServiceStartDate;
	}

	public void setRestCompServiceStartDate(Timestamp restCompServiceStartDate) {
		this.restCompServiceStartDate = restCompServiceStartDate;
	}

	public Timestamp getRestCompSetupDate() {
		return restCompSetupDate;
	}

	public void setRestCompSetupDate(Timestamp restCompSetupDate) {
		this.restCompSetupDate = restCompSetupDate;
	}

	public String getRestCompShortName() {
		return restCompShortName;
	}

	public void setRestCompShortName(String restCompShortName) {
		this.restCompShortName = restCompShortName;
	}

	public String getRestCompSize() {
		return restCompSize;
	}

	public void setRestCompSize(String restCompSize) {
		this.restCompSize = restCompSize;
	}

	public String getRestCompStatus() {
		return restCompStatus;
	}

	public void setRestCompStatus(String restCompStatus) {
		this.restCompStatus = restCompStatus;
	}

	public String getRestCompTitle() {
		return restCompTitle;
	}

	public void setRestCompTitle(String restCompTitle) {
		this.restCompTitle = restCompTitle;
	}

	public String getSchemaName() {
		return schemaName;
	}

	public void setSchemaName(String schemaName) {
		this.schemaName = schemaName;
	}

	public Integer getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(Integer updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Timestamp getUpdatedDatetime() {
		return updatedDatetime;
	}

	public void setUpdatedDatetime(Timestamp updatedDatetime) {
		this.updatedDatetime = updatedDatetime;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getSmtpEmail() {
		return smtpEmail;
	}

	public void setSmtpEmail(String smtpEmail) {
		this.smtpEmail = smtpEmail;
	}

	public String getSmtpAuth() {
		return smtpAuth;
	}

	public void setSmtpAuth(String smtpAuth) {
		this.smtpAuth = smtpAuth;
	}

	public String getEncircleApiToken() {
		return encircleApiToken;
	}

	public void setEncircleApiToken(String encircleApiToken) {
		this.encircleApiToken = encircleApiToken;
	}

	public String getRestCompFaxNumber() {
		return restCompFaxNumber;
	}

	public void setRestCompFaxNumber(String restCompFaxNumber) {
		this.restCompFaxNumber = restCompFaxNumber;
	}

	public String getRestCompWebsite() {
		return restCompWebsite;
	}

	public void setRestCompWebsite(String restCompWebsite) {
		this.restCompWebsite = restCompWebsite;
	}

	public String getRestCompUrl() {
		return restCompUrl;
	}

	public void setRestCompUrl(String restCompUrl) {
		this.restCompUrl = restCompUrl;
	}

	public String getQboCheck() {
		return qboCheck;
	}

	public void setQboCheck(String qboCheck) {
		this.qboCheck = qboCheck;
	}

	public String getQboClientId() {
		return qboClientId;
	}

	public void setQboClientId(String qboClientId) {
		this.qboClientId = qboClientId;
	}

	public String getQboClientSecret() {
		return qboClientSecret;
	}

	public void setQboClientSecret(String qboClientSecret) {
		this.qboClientSecret = qboClientSecret;
	}

	public String getQboRealmId() {
		return qboRealmId;
	}

	public void setQboRealmId(String qboRealmId) {
		this.qboRealmId = qboRealmId;
	}

	public Date getQboStartDate() {
		return qboStartDate;
	}

	public void setQboStartDate(Date qboStartDate) {
		this.qboStartDate = qboStartDate;
	}

	public String getQboVerifierToken() {
		return qboVerifierToken;
	}

	public void setQboVerifierToken(String qboVerifierToken) {
		this.qboVerifierToken = qboVerifierToken;
	}

	public String getQboRedirectUri() {
		return qboRedirectUri;
	}

	public void setQboRedirectUri(String qboRedirectUri) {
		this.qboRedirectUri = qboRedirectUri;
	}

	public String getQboAccessToken() {
		return qboAccessToken;
	}

	public void setQboAccessToken(String qboAccessToken) {
		this.qboAccessToken = qboAccessToken;
	}

	public String getQboRefreshToken() {
		return qboRefreshToken;
	}

	public void setQboRefreshToken(String qboRefreshToken) {
		this.qboRefreshToken = qboRefreshToken;
	}

	
		
}
