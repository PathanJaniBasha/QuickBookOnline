package com.wissen.xcelerate.util;

public class QboUrls {

	public static final String qboCompany = "https://sandbox-quickbooks.api.intuit.com/v3/company";
}
