/**
* Copyright © 2019, xlrestorationsoftware.com ALL RIGHTS RESERVED.
* <p>
* This software is the confidential information of xlrestorationsoftware.com,
* and is licensed as restricted rights software. The use,reproduction, or 
* disclosure of this software is subject to restrictions set forth in your 
* license agreement with xlrestorationsoftware.com.
*/

package com.wissen.xcelerate.util;


/**
 * @author Rama
 *
 */
public interface XcelerateConstants {
	public String LOGIN_SUCCESS = "Login Successfull!";
	public String LOGIN_FAILURE1 = "User Id does not exist! Please enter the correct username.";
	public String LOGIN_FAILURE2 = "Incorrect Username/Password";
	public String LOGIN_FAILURE3 = "User Id is \"deactivated\" in the system";
	public String LOGIN_VALIDATION_ERROR1 = "Username is empty";
	public String LOGIN_VALIDATION_ERROR2 = "Password is empty";
	public String SAVE_USER = "User details saved successfully!";
	public String SUCCESS="success";
	public String FAILURE="failure";
	
	public String SAVE_USER_FAILURE1="Username already exists ! Please provide different username!";
	
	public String SAVE_ROLE_SUCCESS="Role saved successfully!";
	public String ROLE_VALIDATION_ERROR="Role already exist!";
	
	public String MASTER_NUMBER="Master Number";
	
	public String JOB="Job";
	
	public String SAVE_MASTER_NUMBER="Master Number Saved Successfully!";
	
	public String FORM_URL="http://faisedev01.eastus.cloudapp.azure.com:9000/#/Login";
	
	public String STATUS_ACTIVE="Active";
	
	public String STATUS_IN_ACTIVE="In-Active";
	
	public String INSURANCE_COMPANY="Insurance Company";
	
	public String CUSTOMER_COMPANY = "Customer Company";
	
	public String SAVE_EXTERNAL_AGENCY="Organization Details Saved Successfully!";
	
	public String ADJUSTER="Adjuster";
	
	public String PROGRAM_TYPE="Program Type";
	
	public String YEAR_BUILT="Year Built";
	
	public String CAUSE_OF_LOSS="Cause of Loss";
	
	public String PROJECT_MANAGER = "Project Manager";
	
	public String PROGRAM_COORDINATOR="Program Coordinator";
	
	public String SALES = "Sales Representative";
	
	public String ESTIMATOR="Estimator";
	
	public String STATUS_NEW = "New";
	
	public String SAVE_NOTES="Notes added successfully!";
	
	public String MAST_NUM_PREFIX="M";
	
	public String JOB_PREFIX="FN";
	
	public String TASK_PREFIX="T#";
	
	public String TASK_PACK_PREFIX="TP";
	
	public String INSURANCE_AGENT="Insurance Agent";
	
	public String TPA="Third Party Administrator";
	
	public String ORG_TYPE_TPA = "TPA";
	
	public String DEFAULT_TIMEZONE="US/Eastern";
	
	public String SCHEMA="tenant1";
	
	public String ACCESS_YES="Y";
	
	public String ACCESS_NO="N";
	
	public String MASTER_COPY_YES="Y";
	
	public String MASTER_COPY_NO="N";
	
	public String IS_INSURED_YES="Y";
	
	public String IS_INSURED_NO="N";
	
	public String BILLING_ADDR_SAME="Y";
	
	public String BILLING_ADDR_DIFFERENT="N";
	
	public String NOT_AUTHORIZED="you are not authorized to view this page";
	
	public String ONE_TIME_TRUE="True";
	
	public String ONE_TIME_FALSE="False";
	
	public String SAVE_JOB_DETAILS="Job details saved successfully!";
		
	public String CUSTOMER="Customer";
	
	public String PROPERTY_MANAGER="Property Manager";
	
	public String COMPANY="Company";
	
	public String ALL_LOCATIONS = "*";
	
	public String SUPERVISOR = "Supervisor";
	
	public String COORDINATOR = "Coordinator";
	
	public String FINANCE = "Finance";
	
	public String SOURCE = "xcelerate";
	
	public String FILE_TYPE_DOCUMENT = "Document";
	
	public String FILE_TYPE_PICTURE="Picture";
	
	public String FILE_TYPE_ESTIMATE="Estimate";
	
	public String SAVE_COMPANY_FAILURE1="Company already exist!";
	
	public String STATUS_DELETED="Deleted";
	
	public String TASK_STATUS_INPROGRESS = "In Progress";
	
	//Job Status
	
	public String JOB_STATUS_SALES="Sales";
	
	public String JOB_STATUS_ESTIMATING="Estimating";
	
	public String JOB_STATUS_INVOICING = "Invoicing";
	
	public String JOB_STATUS_RECEIVABLES = "Receivables";
	
	public String JOB_STATUS_PLANNING = "Planning";
	
	public String JOB_STATUS_PRODUCTION = "Production";
	
	public String JOB_STATUS_CLOSED = "Closed";
	
	public String JOB_STATUS_REJECTED = "Rejected";
	
	public String JOB_STATUS_REOPEN = "Reopen";
	
	public String JOB_STATUS_WARRANTY = "Warranty";
	
	public String TASK_STATUS_OPEN = "Open";
	
	public String TASK_STATUS_TODO = "To Do";
	
	public String DIVISION = "Division";
	
	public String USER = "User";
	
	public String ROLE = "Role";
	
	public String MIN_CREATED_DATE="2016-12-31 23:59:59"; 
	
	public String MAST_NUM_STATUS_OPEN = "Open";
	
	public String FORM_SOURCE = "Xcelerate";
	
	public int REGULAR_WORK_MINUTES = 480;
	
	public String NPS_URL="http://faisedev01.eastus.cloudapp.azure.com:8081/xcelerate/nps";
	
	public String REFERRED_SOURCE = "Referred Source";
	
	public String SUPPORT_EMAIL = "xcelerate@wisseninfotech.com";
		
}
