package com.wissen.xcelerate.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class DateUtil {

	public Date formatDate(String dbDate) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Date parseDate = null;
		try {
			parseDate = sdf.parse(dbDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return parseDate;
	}
	
	public Date getCurrentTime(String timezone){
		Date currentTime=null;
		try {
			Date date = new Date();
			DateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
			df.setTimeZone(TimeZone.getTimeZone(timezone));
			currentTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").parse(df.format(date));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return currentTime;
	}
}


