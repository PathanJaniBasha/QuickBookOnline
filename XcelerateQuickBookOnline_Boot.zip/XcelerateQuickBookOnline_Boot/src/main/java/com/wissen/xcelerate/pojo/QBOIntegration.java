package com.wissen.xcelerate.pojo;

import java.io.Serializable;

import com.intuit.oauth2.client.OAuth2PlatformClient;
import com.intuit.oauth2.config.OAuth2Config;

public class QBOIntegration implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private OAuth2PlatformClient client;
	private OAuth2Config oauth2Config;
	private String redirectUri;
	private int restCompId;
	
	public QBOIntegration(){
		}

	public OAuth2PlatformClient getClient() {
		return client;
	}

	public void setClient(OAuth2PlatformClient client) {
		this.client = client;
	}

	public OAuth2Config getOauth2Config() {
		return oauth2Config;
	}

	public void setOauth2Config(OAuth2Config oauth2Config) {
		this.oauth2Config = oauth2Config;
	}

	public String getRedirectUri() {
		return redirectUri;
	}

	public void setRedirectUri(String redirectUri) {
		this.redirectUri = redirectUri;
	}

	public int getRestCompId() {
		return restCompId;
	}

	public void setRestCompId(int restCompId) {
		this.restCompId = restCompId;
	}
	
	
	
	}
