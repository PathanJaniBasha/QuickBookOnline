package com.wissen.xcelerate.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;
import com.wissen.xcelerate.model.RestCompDetails;

@org.springframework.stereotype.Repository
public interface RestCompDetailsRepository extends JpaRepository<RestCompDetails, Long>{
	RestCompDetails findByRestCompId(@Param("restCompId") int restCompId);
	RestCompDetails findByQboRealmId(@Param("qboRealmId") String qboRealmId);
}
