package com.wissen.xcelerate.queue;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "rabbitmq")
public class RabbitMQProperties {

    private String queueName;
    private String exchangeName;
    private String routingKey;
    private String webhookQueueName;
    private String webhookRoutingKey;
    
    public String getQueueName() {
        return queueName;
    }

    public void setQueueName(String queueName) {
        this.queueName = queueName;
    }

    public String getExchangeName() {
        return exchangeName;
    }

    public void setExchangeName(String exchangeName) {
        this.exchangeName = exchangeName;
    }

    public String getRoutingKey() {
        return routingKey;
    }

    public void setRoutingKey(String routingKey) {
        this.routingKey = routingKey;
    }

	public String getWebhookQueueName() {
		return webhookQueueName;
	}

	public void setWebhookQueueName(String webhookQueueName) {
		this.webhookQueueName = webhookQueueName;
	}

	public String getWebhookRoutingKey() {
		return webhookRoutingKey;
	}

	public void setWebhookRoutingKey(String webhookRoutingKey) {
		this.webhookRoutingKey = webhookRoutingKey;
	}

	
}


