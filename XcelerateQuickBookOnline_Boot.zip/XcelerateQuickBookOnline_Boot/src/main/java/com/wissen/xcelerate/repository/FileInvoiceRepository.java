package com.wissen.xcelerate.repository;

import java.util.List;


import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;

import com.wissen.xcelerate.model.FileInvoice;

@org.springframework.stereotype.Repository
public interface FileInvoiceRepository extends Repository<FileInvoice, Long>{

	FileInvoice findByDocNo(@Param("docNo") String docNo);
	
	void delete(FileInvoice fileInvoice);
	
	List<FileInvoice> findByFileNumber(@Param("fileNumber") String fileNumber);

	FileInvoice save(FileInvoice fileInvoice);
	
	FileInvoice findByQboRefId(@Param("qboRefId") String qboRefId);
	
}
