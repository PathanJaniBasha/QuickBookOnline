/**
 * 
 */
package com.wissen.xcelerate.pojo;

/**
 * @author 503172959
 *
 */
public class WebhookEntity {

	private String realmId;
	private Entity entity;
	public WebhookEntity(){}
	public String getRealmId() {
		return realmId;
	}
	public void setRealmId(String realmId) {
		this.realmId = realmId;
	}
	public Entity getEntity() {
		return entity;
	}
	public void setEntity(Entity entity) {
		this.entity = entity;
	}
	
	
}
