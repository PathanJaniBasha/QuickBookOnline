/**
 * 
 */
package com.wissen.xcelerate.queue;

import static com.intuit.ipp.query.GenerateQuery.$;
import static com.intuit.ipp.query.GenerateQuery.select;
import java.math.RoundingMode;
import java.util.Date;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.intuit.ipp.core.Context;
import com.intuit.ipp.core.ServiceType;
import com.intuit.ipp.data.Invoice;
import com.intuit.ipp.data.ReferenceType;
import com.intuit.ipp.exception.FMSException;
import com.intuit.ipp.query.GenerateQuery;
import com.intuit.ipp.security.OAuth2Authorizer;
import com.intuit.ipp.services.DataService;
import com.intuit.ipp.services.QueryResult;
import com.intuit.ipp.util.Config;
import com.intuit.oauth2.client.OAuth2PlatformClient;
import com.intuit.oauth2.config.Environment;
import com.intuit.oauth2.config.OAuth2Config;
import com.intuit.oauth2.data.BearerTokenResponse;
import com.intuit.oauth2.exception.OAuthException;
import com.wissen.xcelerate.model.FileInvoice;
import com.wissen.xcelerate.model.RestCompDetails;
import com.wissen.xcelerate.pojo.Entity;
import com.wissen.xcelerate.pojo.WebhookEntity;
import com.wissen.xcelerate.repository.FileInvoiceRepository;
import com.wissen.xcelerate.repository.RestCompDetailsRepository;
import com.wissen.xcelerate.tenant.TenantInterceptor;
import com.wissen.xcelerate.util.DateUtil;
import com.wissen.xcelerate.util.XcelerateConstants;

/**
 * @author 503172959
 *
 */
@Component
public class InvoiceListner {

	private static final Logger logger = LogManager.getLogger(InvoiceListner.class);
	@Autowired
	private RestCompDetailsRepository repository;
	@Autowired
	private FileInvoiceRepository fileInvoiceRepository;

	@Autowired
	private QboUrlProperties urls;
	
	public void webhookNotifications(byte[] message) {
	System.out.println("=======Webhook listner is work flow is Started===========");
	String msg = new String(message);
	RestCompDetails  company=null;
	boolean value=false;
	String url = urls.getCompanyurl();
	System.out.println(url);
	System.out.println(msg);
	WebhookEntity webhookEntity = new Gson().fromJson(msg, WebhookEntity.class);
	Entity entity=webhookEntity.getEntity();
	String realmeId=webhookEntity.getRealmId();
    System.out.println(realmeId);
	System.out.println(entity.getId());
	System.out.println(entity.getOperation());
	if(realmeId!=null) {
		company=repository.findByQboRealmId(realmeId);
		String tenant=company.getSchemaName();
		 if(entity.getOperation().equalsIgnoreCase("Delete")) {
			
			    deleteInvoice(entity);
				
			}
		else {
		Invoice parent = GenerateQuery.createQueryEntity(Invoice.class);
		String query = select($(parent)).where($(parent.getId()).eq(entity.getId()))
				.generate();
          System.out.println(query);
          try {
			TenantInterceptor tenantInterceptor=new TenantInterceptor();
			value=tenantInterceptor.preHandle(tenant);
			if(value) {
			DataService service = getDataService(url, company);
			getQboInvoice(entity, query, service,value);
			}

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			RestCompDetails restCompany = getRefreshToken(company.getRestCompId());
			try {
				TenantInterceptor tenantInterceptor=new TenantInterceptor();
				value=tenantInterceptor.preHandle(tenant);
				if(value) {
				DataService service = getDataService(url, restCompany);
				getQboInvoice(entity, query, service,value);
				}
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				
				System.out.println(e1.getMessage());
			}
		}
	}
	
	}		
			
}

	/**
	 * @param entity
	 */
	
	private void deleteInvoice(Entity entity) {
		System.out.println("======= Delete Invoice opration operation========");
		try {
		FileInvoice invoice=fileInvoiceRepository.findByQboRefId(entity.getId());
		if(invoice!=null) {
			invoice.setStatus(XcelerateConstants.STATUS_DELETED);
			fileInvoiceRepository.save(invoice);
			System.out.println("=======  Invoice Deleted Sucessfully========");
		}
		}
		catch (Exception e) {
			System.out.println(e.getMessage());
			System.out.println(entity.getId()+"Invoice Document is not Present in Xcelerate");
			
		}
		
	}

	/**
	 * @param entity
	 * @param query
	 * @param service
	 * @throws FMSException
	 */
	private void getQboInvoice(Entity entity, String query, DataService service, boolean tenant) throws FMSException {
		QueryResult queryResult = service.executeQuery(query);

		ObjectMapper mapper = new ObjectMapper();
		try {
			String jsonInString = mapper.writeValueAsString(queryResult);
			System.out.println(jsonInString);

		} catch (JsonProcessingException e) {
			logger.error("Exception while getting company info ", e);
			System.out.println(e.getMessage());

		}
		if (queryResult != null && queryResult.getEntities().size() > 0) {
			
			Invoice retrivalInvoice = (Invoice) queryResult.getEntities().get(0);
			String retiveInvoice = processResponse("Invoice Failed", retrivalInvoice);
			System.out.println(retiveInvoice);
			String docNumber = retrivalInvoice.getDocNumber();
			String docId=retrivalInvoice.getId();
			Float totalamount = retrivalInvoice.getTotalAmt().setScale(2, RoundingMode.HALF_UP).floatValue();
			Date date = retrivalInvoice.getMetaData().getLastUpdatedTime();
			ReferenceType type = retrivalInvoice.getCustomerRef();
			String name = type.getName();
			System.out.println("Customer Name is...>" + name);

			String operation = entity.getOperation();

			if (operation.equalsIgnoreCase("Create")) {
				System.out.println("======= Create operation========");
				FileInvoice invoice = new FileInvoice();
				invoice.setDocType("Invoice");
				invoice.setSource("Qbo");
				invoice.setFileNumber(name);
				invoice.setDocNo(docNumber);
				invoice.setQboRefId(docId);
			    invoice.setDocAmt(totalamount);
				System.out.println(totalamount);
				invoice.setDocDate(date);
				invoice.setCreatedDatetime(new java.sql.Timestamp(
						new DateUtil().getCurrentTime(XcelerateConstants.DEFAULT_TIMEZONE).getTime()));
				invoice.setStatus(XcelerateConstants.STATUS_ACTIVE);
				fileInvoiceRepository.save(invoice);
				System.out.println("======= Invoice Created in Xcelerate Sucefully========");
			} else if (operation.equalsIgnoreCase("Update")) {
				System.out.println("======= Update operation========");
				FileInvoice invoice=fileInvoiceRepository.findByDocNo(docNumber);
				if(invoice!=null) {
				invoice.setDocType("Invoice");
				invoice.setSource("Qbo");
				invoice.setFileNumber(name);
				invoice.setDocNo(docNumber);
				invoice.setQboRefId(docId);
				invoice.setDocAmt(totalamount);
				System.out.println(totalamount);
				invoice.setDocDate(date);
				invoice.setUpdatedDatetime(new java.sql.Timestamp(
						new DateUtil().getCurrentTime(XcelerateConstants.DEFAULT_TIMEZONE).getTime()));
				invoice.setStatus(XcelerateConstants.STATUS_ACTIVE);
				fileInvoiceRepository.save(invoice);
				System.out.println("======= Invoice Updated in Xcelerate Sucefully========");
				}
				else {
					System.out.println("======= Create operation========");
					FileInvoice invoicenew = new FileInvoice();
					invoicenew.setDocType("Invoice");
					invoicenew.setSource("Qbo");
					invoicenew.setFileNumber(name);
					invoicenew.setDocNo(docNumber);
					invoicenew.setDocAmt(totalamount);
					invoicenew.setQboRefId(docId);
					System.out.println(totalamount);
					invoicenew.setDocDate(date);
					invoicenew.setCreatedDatetime(new java.sql.Timestamp(
							new DateUtil().getCurrentTime(XcelerateConstants.DEFAULT_TIMEZONE).getTime()));
					invoicenew.setStatus(XcelerateConstants.STATUS_ACTIVE);
					fileInvoiceRepository.save(invoice);
					System.out.println("======= Invoice Created in Xcelerate Sucefully========");
				}
			} 

		}

	}

	private DataService getDataService(String url, RestCompDetails details) throws FMSException {
		System.out.println(Config.BASE_URL_QBO);
		System.out.println(url);
		Config.setProperty(Config.BASE_URL_QBO, url);
		String realmId = details.getQboRealmId();
		System.out.println(realmId);
		if (StringUtils.isEmpty(realmId)) {
			logger.error(new JSONObject()
					.put("response", "No realm ID.  QBO calls only work if the accounting scope was passed!")
					.toString());
		}

		String accessToken = details.getQboAccessToken();
		System.out.println(accessToken);
		String refreshToken = details.getQboRefreshToken();
		System.out.println(refreshToken);
		// create oauth object
		OAuth2Authorizer oauth = new OAuth2Authorizer(accessToken);
		// create context QBO
		Context context = new Context(oauth, ServiceType.QBO, realmId);
		DataService service = new DataService(context);
		return service;
	}

	private String processResponse(String failureMsg, Invoice invoice) {

		ObjectMapper mapper = new ObjectMapper();
		try {
			String jsonInString = mapper.writeValueAsString(invoice);
			System.out.println(jsonInString);
			return jsonInString;
		} catch (JsonProcessingException e) {
			logger.error("Exception while getting company info ", e);
			System.out.println(new JSONObject().put("response", failureMsg).toString());
			return new JSONObject().put("response", failureMsg).toString();

		}

	}

	private RestCompDetails getRefreshToken(int restCompId) {
		RestCompDetails details = null;
		try {
			details = repository.findByRestCompId(restCompId);
			String cliendId = details.getQboClientId();
			String clientSecret = details.getQboClientSecret();
			String refreshToken = details.getQboRefreshToken();
			OAuth2Config oauth2Config = new OAuth2Config.OAuth2ConfigBuilder(cliendId, clientSecret) // set client id,
																										// secret
					.callDiscoveryAPI(Environment.SANDBOX) // call discovery API to populate urls
					.buildConfig();
			OAuth2PlatformClient client = new OAuth2PlatformClient(oauth2Config);
			BearerTokenResponse bearerTokenResponse = client.refreshToken(refreshToken);
			String updatedAccessToken = bearerTokenResponse.getAccessToken();
			String updatedRefreshToken = bearerTokenResponse.getRefreshToken();

			details.setQboAccessToken(updatedAccessToken);
			details.setQboRefreshToken(updatedRefreshToken);
			details = repository.saveAndFlush(details);
		} catch (OAuthException e1) {
			// TODO Auto-generated catch block
			System.out.println(e1.getMessage());
		}
		return details;
	}

	/*
	 * String typeName=type.getType(); String value=type.getValue(); if
	 * (type.getName().matches(":")) {
	 * System.out.println("name contains both parent customer and job name");
	 * System.out.println(type.getName()); String[] parts =
	 * type.getName().split(":"); name = parts[1]; // System.out.println(name); }
	 * else { name=type.getName();
	 * System.out.println("only job customer===========>"+name); }
	 */

}