package com.wissen.xcelerate.service;



import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.intuit.oauth2.client.OAuth2PlatformClient;
import com.intuit.oauth2.config.Environment;
import com.intuit.oauth2.config.OAuth2Config;
import com.wissen.xcelerate.model.RestCompDetails;
import com.wissen.xcelerate.pojo.QBOIntegration;
import com.wissen.xcelerate.pojo.QuickBookOnlineTokenDetails;
import com.wissen.xcelerate.pojo.StatusMessage;
import com.wissen.xcelerate.repository.RestCompDetailsRepository;
import com.wissen.xcelerate.util.XcelerateConstants;

@Service
public class OAuth2PlatformClientFactory {

	@Autowired
	private RestCompDetailsRepository repository;
	
	QBOIntegration qboIntegration;
	String csrfToken;
	QuickBookOnlineTokenDetails quickbookOnline;
	
	public QuickBookOnlineTokenDetails getQuickbook() {
		return quickbookOnline;
	}
	public void setQuickbook(QuickBookOnlineTokenDetails quickbook) {
		quickbookOnline = quickbook;
	}



	private static final Logger logger = LogManager.getLogger(OAuth2PlatformClientFactory.class);

	public QBOIntegration getOAuth2PlatformClient(int restCompId) {
		QBOIntegration qbo=new QBOIntegration();
		try {
		logger.info("Inside OAuth2PlatformClientFactory services of Xcelerate App"  );
		RestCompDetails details=repository.findByRestCompId(restCompId);
		logger.info(details);
		String cliendId=details.getQboClientId();
		logger.info(cliendId);		
		String clientSecret=details.getQboClientSecret();
		logger.info(clientSecret);		
		String redirectUri=details.getQboRedirectUri();
		logger.info(redirectUri);
		logger.info("intitialize OAuth Config Object"  );
		// intitialize a single thread executor, this will ensure only one thread processes the queue
		OAuth2Config oauth2Config = new OAuth2Config.OAuth2ConfigBuilder(cliendId, clientSecret) //set client id, secret
				.callDiscoveryAPI(Environment.SANDBOX) // call discovery API to populate urls
				.buildConfig();
		OAuth2PlatformClient client  = new OAuth2PlatformClient(oauth2Config);
		logger.info("intitialize OAuth Config Object is Completed"  );
		qbo.setRedirectUri(redirectUri);
		qbo.setClient(client);
		qbo.setOauth2Config(oauth2Config);
		qbo.setRestCompId(restCompId);
		setQbo(qbo);
		
		}
		catch (Exception e) {
			logger.error("Exception in OAuth2PlatformClientFactory Service", e);
		}
		
		return qbo;
	}
  public StatusMessage updateQuickBookTokenDetails(QuickBookOnlineTokenDetails details) {
	  StatusMessage message=new StatusMessage();
	  logger.info("Inside the  Update Token Details method"  );
	  try {
	  setQuickbook(details);
	  int restCompId=details.getRestCompId();
	  String accessToken=details.getAccessToken();
	  String realmId= details.getRealmId();
	  String refreshToken=details.getRefreshToken();
	 RestCompDetails restCompantDetails=repository.findByRestCompId(restCompId);
	 logger.info("Before Update RestCompDetails model class"  );
	 logger.info(restCompantDetails);
	 logger.info("============ End ============"  );
	 restCompantDetails.setQboRealmId(realmId);
	 restCompantDetails.setQboAccessToken(accessToken);
	 restCompantDetails.setQboRefreshToken(refreshToken);
	 restCompantDetails.setQboVerifierToken("true");
	 RestCompDetails newRestCompantDetails=repository.saveAndFlush(restCompantDetails);
	 logger.info("After Update RestCompDetails model class"  );
	 logger.info(newRestCompantDetails);
	 logger.info("============ End ============"  );
	 message.setStatus(XcelerateConstants.SUCCESS);
	 message.setMessage("Restoration Company details are Update Successfully");
	 logger.info("Restoration Company details are Update Successfully");
	  }
	  catch (Exception e) {
		  message.setStatus(XcelerateConstants.FAILURE);
		  message.setMessage(e.getMessage());
		  logger.error(XcelerateConstants.FAILURE);
		  logger.error("Error in Restoration Company details are Updates");
		  logger.error(e.getMessage());
	}
	  return message;
	  
  }
	

	public void setQbo(QBOIntegration qbo) {
		qboIntegration=qbo;
	}
	
	public QBOIntegration getQBOIntegration() {
		return qboIntegration;
	}
	
   public String getCsrfToken() {
		return csrfToken;
	}



	public void setCsrfTokenValue(String csrf) {
		csrfToken = csrf;
	}

	
	
	
}
