/**
 * 
 */
package com.wissen.xcelerate.pojo;

import java.io.Serializable;

/**
 * @author 503172959
 *
 */
public class JobUpdate implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private CustomerDetails parent;
	private CustomerDetails jobDetails;
	
	public JobUpdate() {}

	public CustomerDetails getParent() {
		return parent;
	}

	public void setParent(CustomerDetails parent) {
		this.parent = parent;
	}

	public CustomerDetails getJobDetails() {
		return jobDetails;
	}

	public void setJobDetails(CustomerDetails jobDetails) {
		this.jobDetails = jobDetails;
	}

	
}
