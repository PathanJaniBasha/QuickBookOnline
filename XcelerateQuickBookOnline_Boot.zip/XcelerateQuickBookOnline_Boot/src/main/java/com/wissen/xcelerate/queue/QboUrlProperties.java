package com.wissen.xcelerate.queue;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConfigurationProperties(prefix = "qbo")
public class QboUrlProperties {

    private String companyurl;
    private String verifierToken;

	public String getCompanyurl() {
		return companyurl;
	}

	public void setCompanyurl(String companyurl) {
		this.companyurl = companyurl;
	}

	public String getVerifierToken() {
		return verifierToken;
	}

	public void setVerifierToken(String verifierToken) {
		this.verifierToken = verifierToken;
	}
    
    
    

}


