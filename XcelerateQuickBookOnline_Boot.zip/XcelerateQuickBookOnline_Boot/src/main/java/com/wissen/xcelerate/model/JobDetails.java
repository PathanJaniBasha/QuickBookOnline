package com.wissen.xcelerate.model;

/**
* Copyright © 2019, xlrestorationsoftware.com ALL RIGHTS RESERVED.
* <p>
* This software is the confidential information of xlrestorationsoftware.com,
* and is licensed as restricted rights software. The use,reproduction, or 
* disclosure of this software is subject to restrictions set forth in your 
* license agreement with xlrestorationsoftware.com.
*/


/**
* Copyright © 2019, xlrestorationsoftware.com ALL RIGHTS RESERVED.
* <p>
* This software is the confidential information of xlrestorationsoftware.com,
* and is licensed as restricted rights software. The use,reproduction, or 
* disclosure of this software is subject to restrictions set forth in your 
* license agreement with xlrestorationsoftware.com.
*/



import java.io.Serializable;
import java.util.Date;

import javax.persistence.*;

//import com.wissen.xcelerate.pojo.SubJobDetails;


/**
 * The persistent class for the job_details database table.
 * 
 */
@Entity
@Table(name="job_details")
public class JobDetails implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="job_id")
	private int jobId;

    @Column(name="job_code")
	private String jobCode;
	
	@Column(name="job_name")
	private String jobName;

	@Column(name="job_desc")
	private String jobDesc;

	@Column(name="job_hash_code")
	private String jobHashCode;

    @Column(name="job_type")
	private String jobType;
    @Column(name="qb_status")
	private String qbStatus;
	
	@Column(name="qb_date")
	private Date qbDate;

	@Column(name="qb_flag")
	private String qbFlag;
	//QBO Related columns
    @Column(name="qbo_status")
	private String qboStatus;
	@Column(name="qb_created_source")
	private String qbCreatedSource;
	@Column(name="qbo_ref_id")
	private String qboRefId;

	public JobDetails() {
	}

	public int getJobId() {
		return jobId;
	}

	public void setJobId(int jobId) {
		this.jobId = jobId;
	}

	public String getJobCode() {
		return jobCode;
	}

	public void setJobCode(String jobCode) {
		this.jobCode = jobCode;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public String getJobDesc() {
		return jobDesc;
	}

	public void setJobDesc(String jobDesc) {
		this.jobDesc = jobDesc;
	}

	public String getJobHashCode() {
		return jobHashCode;
	}

	public void setJobHashCode(String jobHashCode) {
		this.jobHashCode = jobHashCode;
	}

	public String getJobType() {
		return jobType;
	}

	public void setJobType(String jobType) {
		this.jobType = jobType;
	}

	public String getQbStatus() {
		return qbStatus;
	}

	public void setQbStatus(String qbStatus) {
		this.qbStatus = qbStatus;
	}

	public Date getQbDate() {
		return qbDate;
	}

	public void setQbDate(Date qbDate) {
		this.qbDate = qbDate;
	}

	public String getQbFlag() {
		return qbFlag;
	}

	public void setQbFlag(String qbFlag) {
		this.qbFlag = qbFlag;
	}

	public String getQboStatus() {
		return qboStatus;
	}

	public void setQboStatus(String qboStatus) {
		this.qboStatus = qboStatus;
	}

	public String getQbCreatedSource() {
		return qbCreatedSource;
	}

	public void setQbCreatedSource(String qbCreatedSource) {
		this.qbCreatedSource = qbCreatedSource;
	}

	public String getQboRefId() {
		return qboRefId;
	}

	public void setQboRefId(String qboRefId) {
		this.qboRefId = qboRefId;
	}

	
}