package com.wissen.xcelerate.model;

import java.io.Serializable;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.sql.Timestamp;
import java.util.Date;

@Entity
@Table(name="file_invoice")
public class FileInvoice implements Serializable 
{
private static final long serialVersionUID = 1L;
    
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
@Column(name="doc_id")
private long docId;

@Column(name="doc_date")
@JsonFormat(pattern = "yyyy-MM-dd")
@Temporal(TemporalType.DATE)
private Date docDate;

@Column(name="doc_no")
private String docNo;

@Column(name="doc_type")
private String docType;

@Column(name="doc_amt")
private Float docAmt;

@Column(name="created_by")
private int createdBy;

@Column(name="created_datetime")
private Timestamp createdDatetime;

@Column(name="updated_by")
private int updatedBy;

@Column(name="updated_datetime")
private Timestamp updatedDatetime;

@Column(name="source")
private String source;

@Column(name="file_number")
private String fileNumber;

@Column(name="qbo_ref_id")
private String qboRefId;

@Column(name="status")
private String status;




public FileInvoice() {}

public long getDocId() {
    return docId;
}

public void setDocId(long docId) {
    this.docId = docId;
}

public Date getDocDate() {
    return docDate;
}

public void setDocDate(Date docDate) {
    this.docDate = docDate;
}

public String getDocNo() {
    return docNo;
}

public void setDocNo(String docNo) {
    this.docNo = docNo;
}

public String getDocType() {
    return docType;
}

public void setDocType(String docType) {
    this.docType = docType;
}

public Float getDocAmt() {
    return docAmt;
}

public void setDocAmt(Float docAmt) {
    this.docAmt = docAmt;
}

public int getCreatedBy() {
    return createdBy;
}

public void setCreatedBy(int createdBy) {
    this.createdBy = createdBy;
}

public Timestamp getCreatedDatetime() {
    return createdDatetime;
}

public void setCreatedDatetime(Timestamp createdDatetime) {
    this.createdDatetime = createdDatetime;
}

public int getUpdatedBy() {
    return updatedBy;
}

public void setUpdatedBy(int updatedBy) {
    this.updatedBy = updatedBy;
}

public Timestamp getUpdatedDatetime() {
    return updatedDatetime;
}

public void setUpdatedDatetime(Timestamp updatedDatetime) {
    this.updatedDatetime = updatedDatetime;
}

public String getSource() {
    return source;
}

public void setSource(String source) {
    this.source = source;
}

public String getFileNumber() {
	return fileNumber;
}

public void setFileNumber(String fileNumber) {
	this.fileNumber = fileNumber;
}

public String getQboRefId() {
	return qboRefId;
}

public void setQboRefId(String qboRefId) {
	this.qboRefId = qboRefId;
}

public String getStatus() {
	return status;
}

public void setStatus(String status) {
	this.status = status;
}


}