package com.wissen.xcelerate.repository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.Repository;
import org.springframework.data.repository.query.Param;

import com.wissen.xcelerate.model.JobDetails;

public interface JobDetailsRepository extends Repository<JobDetails, Long>{

	 @Query("select j from JobDetails j where REPLACE(REPLACE(j.jobCode, 'FN', ''),'_',' ')=:jobCode")
	JobDetails findByJobCode(@Param("jobCode") String jobCode);
	 JobDetails save(JobDetails job); 
}
