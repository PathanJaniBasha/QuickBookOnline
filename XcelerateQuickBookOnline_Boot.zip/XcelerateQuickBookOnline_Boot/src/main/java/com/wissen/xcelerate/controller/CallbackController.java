package com.wissen.xcelerate.controller;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.intuit.oauth2.client.OAuth2PlatformClient;
import com.intuit.oauth2.data.BearerTokenResponse;
import com.intuit.oauth2.exception.OAuthException;
import com.wissen.xcelerate.pojo.QBOIntegration;
import com.wissen.xcelerate.pojo.QuickBookOnlineTokenDetails;
import com.wissen.xcelerate.pojo.StatusMessage;
import com.wissen.xcelerate.service.OAuth2PlatformClientFactory;

/**
 * @author
 *
 */

@RestController
@RequestMapping(value = "/integration/qbo")
public class CallbackController {

	@Autowired
	private OAuth2PlatformClientFactory factory;

	private static final Logger logger = LogManager.getLogger(CallbackController.class);

	/**
	 * This is the redirect handler you configure in your app on
	 * developer.intuit.com The Authorization code has a short lifetime. Hence
	 * Unless a user action is quick and mandatory, proceed to exchange the
	 * Authorization Code for BearerToken
	 * 
	 * @param auth_code
	 * @param state
	 * @param realmId
	 * @param sessionvalue="/",method = RequestMethod.GET
	 * @return
	 */
	@RequestMapping(value = "/oauth2redirect", method = RequestMethod.GET)
	public String callBackFromOAuth(@RequestParam("code") String authCode, @RequestParam("state") String state,
			@RequestParam(value = "realmId", required = false) String realmId, HttpSession session) {

		String status = null;
		QuickBookOnlineTokenDetails quickBookDetails = new QuickBookOnlineTokenDetails();
		logger.info("inside oauth2redirect of Xcelerate App");
		System.out.println("inside oauth2redirect of Xcelerate App");
		try {
			QBOIntegration qbo = factory.getQBOIntegration();
			OAuth2PlatformClient client = qbo.getClient();
			String redirectUri = qbo.getRedirectUri();
			int restCompId = qbo.getRestCompId();
			String csrfToken = factory.getCsrfToken();
			quickBookDetails.setCsrfToken(csrfToken);
			quickBookDetails.setState(state);
			if (csrfToken.equals(state)) {
				quickBookDetails.setRealmId(realmId);
				quickBookDetails.setAuthcode(authCode);
				quickBookDetails.setRedirectUri(redirectUri);
				logger.info("Inside oauth2redirect of XcelerateQuickBook Online -- redirectUri " + redirectUri);
				BearerTokenResponse bearerTokenResponse = client.retrieveBearerTokens(authCode, redirectUri);
				logger.info("Inside oauth2redirect of XcelerateQuickBook Online -- bearerTokenResponse "
						+ bearerTokenResponse);
				quickBookDetails.setAccessToken(bearerTokenResponse.getAccessToken());
				quickBookDetails.setRefreshToken(bearerTokenResponse.getRefreshToken());
				quickBookDetails.setRestCompId(restCompId);
				StatusMessage message = factory.updateQuickBookTokenDetails(quickBookDetails);
				System.out.print(message.getStatus());
				String updateStatus = message.getStatus();
				if (updateStatus.equals("success")) {
					status = "<h2 style='color:DodgerBlue;'> QuickBook Online Connected</h3>"+ " <br><h3 style='color:DodgerBlue;'>Please Close Window and Refresh The Company Setup Screen</h3>";
		
				}

			} else {
				logger.info(" Inside oauth2redirect of XcelerateQuickBook Online csrf token mismatch ");

			}

		} catch (OAuthException e) {
			logger.error("Exception Inside oauth2redirect of XcelerateQuickBook Online callback handler ", e);
			status = "Online QuickBook is Not Connected";
		}
		return status;
	}

	
}
