package com.wissen.xcelerate.controller;

import com.wissen.xcelerate.pojo.QBOIntegration;
import com.wissen.xcelerate.pojo.StatusMessage;
import com.wissen.xcelerate.service.OAuth2PlatformClientFactory;
import com.wissen.xcelerate.util.XcelerateConstants;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpSession;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.view.RedirectView;
import com.intuit.oauth2.config.OAuth2Config;
import com.intuit.oauth2.config.Scope;
import com.intuit.oauth2.exception.InvalidRequestException;

/**
 * @author dderose
 *
 */

@RestController
@RequestMapping(value = "/integration/qbo")
public class OAuth2Controller {
	
	private static final Logger logger = LogManager.getLogger(OAuth2Controller.class);
	
	@Autowired
	private OAuth2PlatformClientFactory factory;
	
	
	    

	
	/**
	 * Controller mapping for connectToQuickbooks button
	 * @return
	 */
	@RequestMapping(value="/connectToQuickbooks",method = RequestMethod.GET)
	public StatusMessage connectToQuickbooks(@RequestParam("restCompId") int restCompId,HttpSession session) {
		StatusMessage message=new StatusMessage();
		logger.info("inside connectToQuickbooks ");
	   try {
			
			QBOIntegration qbo=factory.getOAuth2PlatformClient(restCompId);
			OAuth2Config oauth2Config=qbo.getOauth2Config();
			String csrf = oauth2Config.generateCSRFToken();
			String redirectUri=qbo.getRedirectUri();
			factory.setCsrfTokenValue(csrf);
		    List<Scope> scopes = new ArrayList<Scope>();
			scopes.add(Scope.Accounting);
			scopes.add(Scope.OpenIdAll);
			message.setData(new RedirectView(oauth2Config.prepareUrl(scopes, redirectUri, csrf), true, true, false).getUrl());
		    message.setStatus(XcelerateConstants.SUCCESS);
			
		} catch (InvalidRequestException e) {
			logger.error("Exception calling connectToQuickbooks ", e);
			message.setMessage(e.getMessage());
			 message.setStatus(XcelerateConstants.FAILURE);
		} 
		return message;
	}
	
	
}
