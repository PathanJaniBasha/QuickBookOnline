/**
* Copyright © 2019, xlrestorationsoftware.com ALL RIGHTS RESERVED.
* <p>
* This software is the confidential information of xlrestorationsoftware.com,
* and is licensed as restricted rights software. The use,reproduction, or 
* disclosure of this software is subject to restrictions set forth in your 
* license agreement with xlrestorationsoftware.com.
*/

package com.wissen.xcelerate.tenant;
import org.springframework.stereotype.Component;



@Component
public class TenantInterceptor {

  
 public boolean preHandle(String schemaName)
      throws Exception {
	          boolean tenantSet = false;
    		if(schemaName != null) {
    			TenantContext.setCurrentTenant(schemaName);
        		System.out.println(schemaName);
    	    	tenantSet = true;
    		}
    		
    		else {
    			TenantContext.setCurrentTenant("common");
    	    	tenantSet = true;
    		}
    		
    	
    return tenantSet;
  }

  
  public void postHandle()
		throws Exception {
	  
     TenantContext.clear();
  }
}