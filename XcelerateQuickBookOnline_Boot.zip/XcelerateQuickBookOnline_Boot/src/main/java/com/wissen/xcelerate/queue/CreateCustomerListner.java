package com.wissen.xcelerate.queue;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.intuit.ipp.core.Context;
import com.intuit.ipp.core.ServiceType;
import com.intuit.ipp.data.Customer;
import com.intuit.ipp.data.EmailAddress;
import com.intuit.ipp.data.ModificationMetaData;
import com.intuit.ipp.data.PhysicalAddress;
import com.intuit.ipp.data.ReferenceType;
import com.intuit.ipp.data.TelephoneNumber;
import com.intuit.ipp.exception.FMSException;
import com.intuit.ipp.query.GenerateQuery;
import com.intuit.ipp.security.OAuth2Authorizer;
import com.intuit.ipp.services.DataService;
import com.intuit.ipp.services.QueryResult;
import com.intuit.ipp.util.Config;
import com.intuit.oauth2.client.OAuth2PlatformClient;
import com.intuit.oauth2.config.Environment;
import com.intuit.oauth2.config.OAuth2Config;
import com.intuit.oauth2.data.BearerTokenResponse;
import com.intuit.oauth2.exception.OAuthException;
import com.wissen.xcelerate.model.JobDetails;
import com.wissen.xcelerate.model.RestCompDetails;
import com.wissen.xcelerate.pojo.CustomerDetails;
import com.wissen.xcelerate.pojo.JobUpdate;
import com.wissen.xcelerate.repository.JobDetailsRepository;
import com.wissen.xcelerate.repository.RestCompDetailsRepository;
import com.wissen.xcelerate.service.OAuth2PlatformClientFactory;
import com.wissen.xcelerate.tenant.TenantInterceptor;

import static com.intuit.ipp.query.GenerateQuery.$;
import static com.intuit.ipp.query.GenerateQuery.select;

import java.util.Date;

@Component
public class CreateCustomerListner {
	private static final Logger logger = LogManager.getLogger(CreateCustomerListner.class);

	@Autowired
	OAuth2PlatformClientFactory factory;

	@Autowired
	private RestCompDetailsRepository repository;
	@Autowired
	private QboUrlProperties urls;
	@Autowired
	private JobDetailsRepository jobDetailsRepository;

	public void onMessage(byte[] message) {
		System.out.println("=======Creating Customer is work flow is Started===========");
		String url = urls.getCompanyurl();
		System.out.println(url);
		String msg = new String(message);
		System.out.print(msg);
		JobUpdate jobUpdateDetails = new Gson().fromJson(msg, JobUpdate.class);
		CustomerDetails parentCustomer = jobUpdateDetails.getParent();
		System.out.println(parentCustomer.getCustomerName());
		CustomerDetails job = jobUpdateDetails.getJobDetails();
		System.out.println(job.getCustomerName());
		int restCompId = parentCustomer.getRestCompId();
		Customer parentQoCustomer = getQBOCustomer(parentCustomer);
		Customer qboJob = getQBOCustomer(job);
		String response = null;
		String failureMsg = "Failed";

		try {

			RestCompDetails details = repository.findByRestCompId(restCompId);

			response = jobCreation(url, parentQoCustomer, qboJob, failureMsg, details);

			System.out.println("Final out" + response);

		}

		/*
		 * Handle 401 status code - If a 401 response is received, refresh tokens should
		 * be used to get a new access token, and the API call should be tried again.
		 */
		catch (FMSException e) {
			logger.error("Error while calling executeQuery :: " + e.getMessage());
			System.out.print(e.getMessage());

			RestCompDetails company = getRefreshToken(restCompId);
			try {
				response = jobCreation(url, parentQoCustomer, qboJob, failureMsg, company);
			} catch (FMSException e1) {
				// TODO Auto-generated catch block
				// e1.printStackTrace();
				System.out.println(e1.getMessage());
			}

		}

	}

	/**
	 * @param url
	 * @param parentQoCustomer
	 * @param qboJob
	 * @param failureMsg
	 * @param details
	 * @return
	 * @throws FMSException
	 */
	private String jobCreation(String url, Customer parentQoCustomer, Customer qboJob, String failureMsg,
			RestCompDetails details) throws FMSException {
		String response;
		String tenant = details.getSchemaName();
		System.out.println("Schema name======>>>>>" + tenant);
		DataService service = getDataService(url, details);
		QueryResult queryResult = customerExits(parentQoCustomer, service);

		if (queryResult != null && queryResult.getEntities().size() > 0) {
          System.out.println(" Parent Customer is Exits!"
					+ "Adding Job to Parent Customer");
			response = saveQboJob(qboJob, failureMsg, service, queryResult, tenant);
		} else {
			System.out.println(" Creating Parent Customer");
			response = addQBOParentCustomer(failureMsg, parentQoCustomer, service, qboJob, tenant);
		}
		return response;
	}

	/**
	 * @param parentQoCustomer
	 * @param service
	 * @return
	 * @throws FMSException
	 */
	private QueryResult customerExits(Customer customer, DataService service) throws FMSException {
		Customer parent = GenerateQuery.createQueryEntity(Customer.class);
		String query = select($(parent)).where($(parent.getDisplayName()).eq(customer.getDisplayName())).generate();
		System.out.println("query>>>>>>>>>>>" + query);

		QueryResult queryResult = service.executeQuery(query);
		return queryResult;
	}

	/**
	 * @param qboJob
	 * @param failureMsg
	 * @param service
	 * @param queryResult
	 * @return
	 * @throws FMSException
	 */
	private String saveQboJob(Customer qboJob, String failureMsg, DataService service, QueryResult queryResult,
			String tenant) throws FMSException {
		System.out.println("inside the Adding sub-customer to parent Customer");
		String response = null;
		Customer jobCustomer = null;
		Customer retrivalParent = (Customer) queryResult.getEntities().get(0);
		try {
			QueryResult jobQueryResult = customerExits(qboJob, service);
			if (jobQueryResult != null && jobQueryResult.getEntities().size() > 0) {
                 System.out.println(" Sub- Customer is Already Present");

			} else {
				System.out.println(" Creating Sub Customer Customer");
				jobCustomer = createSubCustomer(retrivalParent,qboJob, service, queryResult, tenant);
			}

			response = processResponse(failureMsg, jobCustomer);
		} catch (Exception e) {
			System.out.println("Error in Creating Sub Customer");
			System.out.println(e.getMessage());
		}
		System.out.println("end of  the Adding sub-customer to parent Customer");
		return response;
	}

	/**
	 * @param qboJob
	 * @param service
	 * @param queryResult
	 * @param tenant
	 * @return
	 * @throws FMSException
	 * @throws Exception
	 */
	private Customer createSubCustomer(Customer retrivalParent,Customer qboJob, DataService service, QueryResult queryResult, String tenant)
			throws FMSException, Exception {
		Customer jobCustomer;
		ReferenceType value = new ReferenceType();
		System.out.println(retrivalParent.getDisplayName());
		value.setName(retrivalParent.getDisplayName());
		value.setType("Customer");
		value.setValue(retrivalParent.getId());
		qboJob.setJob(true);
		qboJob.setParentRef(value);
		qboJob.setRootCustomerRef(value);
		jobCustomer = service.add(qboJob);
		if (jobCustomer != null) {
			String qboRefId = jobCustomer.getId();
			String jobCode = jobCustomer.getDisplayName();
			System.out.println(qboRefId);
			System.out.println(jobCode);
			TenantInterceptor tenantInterceptor = new TenantInterceptor();
			boolean tenantValue = tenantInterceptor.preHandle(tenant);

			if (tenantValue) {
				JobDetails job = jobDetailsRepository.findByJobCode(jobCode);
				job.setQboStatus("Success");
				job.setQboRefId(qboRefId);
				job.setQbCreatedSource("Qbo");
				job.setQbFlag("Y");
				jobDetailsRepository.save(job);
				System.out.println("Job details are Updated Sucessfully");
				System.out.println("===========");
			}
		}
		return jobCustomer;
	}

	private String addQBOParentCustomer(String failureMsg, Customer customer, DataService service, Customer qboJob,
			String tenant) throws FMSException {
		System.out.println("inside the Creating  parent Customer method");
		String response = null;
		Customer jobCustomer = null;
		try {

			System.out.println(customer.getDisplayName());
			System.out.println(service.hashCode());
			Customer resultParentCustomer = service.add(customer);
			if (resultParentCustomer != null) {
				QueryResult jobQueryResult = customerExits(qboJob, service);
				if (jobQueryResult != null && jobQueryResult.getEntities().size() > 0) {

					System.out.println(" Sub- Customer is Already Present");

				} else {
					System.out.println(" Creating Sub Customer Customer");
					jobCustomer = createSubCustomer(resultParentCustomer,qboJob, service, jobQueryResult, tenant);
				}

			}
		
			response = processResponse(failureMsg, jobCustomer);
		}

		catch (Exception e) {
			System.out.println("Error in Creating Parent Customer");
			System.out.println(e.getMessage());
		}
		System.out.println("end of the Creating  parent Customer method");
		return response;
	}

	/**
	 * @param url
	 * @param details
	 * @return
	 * @throws FMSException
	 */
	private DataService getDataService(String url, RestCompDetails details) throws FMSException {
		Config.setProperty(Config.BASE_URL_QBO, url);
		String realmId = details.getQboRealmId();
		System.out.println(realmId);
		if (StringUtils.isEmpty(realmId)) {
			logger.error(new JSONObject()
					.put("response", "No realm ID.  QBO calls only work if the accounting scope was passed!")
					.toString());
		}

		String accessToken = details.getQboAccessToken();
		System.out.println(accessToken);
		String refreshToken = details.getQboRefreshToken();
		System.out.println(refreshToken);
		// create oauth object
		OAuth2Authorizer oauth = new OAuth2Authorizer(accessToken);
		// create context QBO
		Context context = new Context(oauth, ServiceType.QBO, realmId);
		DataService service = new DataService(context);
		return service;
	}

	private RestCompDetails getRefreshToken(int restCompId) {
		RestCompDetails details = null;
		try {
			details = repository.findByRestCompId(restCompId);
			String cliendId = details.getQboClientId();
			String clientSecret = details.getQboClientSecret();
			String refreshToken = details.getQboRefreshToken();
			OAuth2Config oauth2Config = new OAuth2Config.OAuth2ConfigBuilder(cliendId, clientSecret) // set client id,
																										// secret
					.callDiscoveryAPI(Environment.SANDBOX) // call discovery API to populate urls
					.buildConfig();
			OAuth2PlatformClient client = new OAuth2PlatformClient(oauth2Config);
			BearerTokenResponse bearerTokenResponse = client.refreshToken(refreshToken);
			String updatedAccessToken = bearerTokenResponse.getAccessToken();
			String updatedRefreshToken = bearerTokenResponse.getRefreshToken();

			details.setQboAccessToken(updatedAccessToken);
			details.setQboRefreshToken(updatedRefreshToken);
			details = repository.saveAndFlush(details);
		} catch (OAuthException e1) {
			// TODO Auto-generated catch block
			System.out.println(e1.getMessage());
		}
		return details;
	}

	private String processResponse(String failureMsg, Customer resultCustomer) {

		ObjectMapper mapper = new ObjectMapper();
		try {
			String jsonInString = mapper.writeValueAsString(resultCustomer);
			System.out.println(jsonInString);
			return jsonInString;
		} catch (JsonProcessingException e) {
			logger.error("Exception while getting company info ", e);
			System.out.println(new JSONObject().put("response", failureMsg).toString());
			return new JSONObject().put("response", failureMsg).toString();

		}

	}

	private Customer getQBOCustomer(CustomerDetails xceleratePojo) {

		Customer customer = new Customer();
		customer.setActive(true);// enable Customer is Active or not

		// customer.setFullyQualifiedName("Developers Test");
		customer.setDisplayName(xceleratePojo.getCustomerName());
		// customer.setSuffix("jr");
		// customer.setTitle("Mr");
		customer.setMiddleName(xceleratePojo.getFirstName());
		System.out.println("Loss descriptions=============>" + xceleratePojo.getLossDescription());
		customer.setNotes(xceleratePojo.getLossDescription());
		customer.setFamilyName(xceleratePojo.getLastName());
		EmailAddress email = new EmailAddress();
		email.setAddress(xceleratePojo.getEmail());
		customer.setPrimaryEmailAddr(email);
		TelephoneNumber mobile = new TelephoneNumber();
		mobile.setFreeFormNumber(xceleratePojo.getMobile());
		customer.setMobile(mobile);
		TelephoneNumber phone = new TelephoneNumber();
		phone.setFreeFormNumber(xceleratePojo.getWorkPhone());
		customer.setPrimaryPhone(phone);
		customer.setPrintOnCheckName(xceleratePojo.getCustomerName());

		System.out.println("Customer Type=================>>>>>>>>>" + xceleratePojo.getCustomerType());
		/*
		 * ReferenceType type=new ReferenceType();
		 * if(xceleratePojo.getCustomerType().equals("Customer")) {
		 * System.out.println(); type.setType("Customer");
		 * customer.setCustomerTypeRef(type); } else {
		 * type.setType("Customer Organization"); customer.setCustomerTypeRef(type);
		 * customer.setCompanyName("XYZ Company");
		 * 
		 * }
		 */
		PhysicalAddress address = new PhysicalAddress();

		// address.setCountrySubDivisionCode("HYD");
		address.setCity(xceleratePojo.getCity());
		address.setPostalCode(xceleratePojo.getZip());
		address.setLine1(xceleratePojo.getAddress1());
		address.setCountry(xceleratePojo.getState());
		customer.setBillAddr(address);
		ModificationMetaData metaData = new ModificationMetaData();
		metaData.setCreateTime(new Date());
		customer.setMetaData(metaData);
		// customer.setGivenName("QUick Book new");
		return customer;
	}
}
