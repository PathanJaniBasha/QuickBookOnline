package com.wissen.xcelerate.pojo;

import java.io.Serializable;

public class QuickBookOnlineTokenDetails implements Serializable {
    private static final long serialVersionUID = 1L;
	private String redirectUri;
	private String accessToken;
	private String refreshToken;
	private String authcode;
	private String realmId;
	private String csrfToken;
	private String state;
	private int restCompId;
	//private String givenName;
	//private String personDetails;
    //private String email;
    //private String subId;
	public QuickBookOnlineTokenDetails(){}
	public String getRedirectUri() {
		return redirectUri;
	}
	public void setRedirectUri(String redirectUri) {
		this.redirectUri = redirectUri;
	}
	public String getAccessToken() {
		return accessToken;
	}
	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}
	public String getRefreshToken() {
		return refreshToken;
	}
	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}
	public String getAuthcode() {
		return authcode;
	}
	public void setAuthcode(String authcode) {
		this.authcode = authcode;
	}
	public String getRealmId() {
		return realmId;
	}
	public void setRealmId(String realmId) {
		this.realmId = realmId;
	}
	public String getCsrfToken() {
		return csrfToken;
	}
	public void setCsrfToken(String csrfToken) {
		this.csrfToken = csrfToken;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getRestCompId() {
		return restCompId;
	}
	public void setRestCompId(int restCompId) {
		this.restCompId = restCompId;
	}

	

	
}
