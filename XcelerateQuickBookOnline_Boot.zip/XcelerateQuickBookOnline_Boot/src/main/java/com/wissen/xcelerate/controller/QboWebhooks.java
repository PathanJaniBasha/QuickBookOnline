/**
 * 
 */
package com.wissen.xcelerate.controller;

import java.io.UnsupportedEncodingException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Map;
import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.wissen.xcelerate.pojo.Entity;
import com.wissen.xcelerate.pojo.WebhookEntity;
import com.wissen.xcelerate.queue.QboUrlProperties;
import com.wissen.xcelerate.queue.RabbitMQProperties;


/**
 * @author 503172959
 *
 */


@RestController
@RequestMapping(value = "/integration/qbo")
public class QboWebhooks {
	@Autowired
	private RabbitMQProperties rabbitMQProperties;
	@Autowired
    private RabbitTemplate rabbitTemplate;
	
	@Autowired
	private QboUrlProperties urls;

	@RequestMapping(value = "/webhooks", method = RequestMethod.POST)
	public void  qboWebhook(@RequestHeader Map<String,String> headers, @RequestBody String payload) {
		//final String verifier ="02b213ce-46ba-40ff-a94d-dfac2f47b32e";
		 String verifier=urls.getVerifierToken();
		 boolean value= isRequestValid(headers,payload,verifier);
		  System.out.println(value);
		  if(value) {
			 JsonObject jsonObject = new JsonParser().parse(payload).getAsJsonObject();
			 JsonArray  pageName = jsonObject.getAsJsonArray("eventNotifications");
			  for(JsonElement pa : pageName){
		        	JsonObject object = pa.getAsJsonObject();
		        	String realmId =object.get("realmId").getAsString();
		        	System.out.println("reakme id"+realmId);
		        	JsonObject  dataChangeEvent = object.getAsJsonObject("dataChangeEvent");
		        	JsonArray entities = dataChangeEvent.getAsJsonArray("entities");
				for (JsonElement entityElement : entities) {
					JsonObject entity = entityElement.getAsJsonObject();
					Entity pojo = new Gson().fromJson(entity, Entity.class);
					WebhookEntity webhook=new WebhookEntity();
					webhook.setEntity(pojo);
					webhook.setRealmId(realmId);
					String entityName=pojo.getName();
					if(entityName.equalsIgnoreCase("Invoice")) {
						//add Invoice details to Queue.
						rabbitTemplate.convertAndSend(rabbitMQProperties.getExchangeName(),rabbitMQProperties.getWebhookRoutingKey(),webhook);
					}
					
				}
				 

		        }
		  }
		  
	}
	
	
	   
	   
	   public boolean isRequestValid(Map<String, String> headers, String payload, String verifier) {
		   final String SIGNATURE = "intuit-signature";
		   final String ALGORITHM = "HmacSHA256";
	      String signature = headers.get(SIGNATURE);
	      if (signature == null) {
	         return false;
	      }
	      try {
	         SecretKeySpec secretKey = new SecretKeySpec(verifier.getBytes("UTF-8"), ALGORITHM);
	         Mac mac = Mac.getInstance(ALGORITHM);
	         mac.init(secretKey);
	         String hash = Base64.getEncoder().encodeToString(mac.doFinal(payload.getBytes()));
	         return hash.equals(signature);
	      } catch (NoSuchAlgorithmException | UnsupportedEncodingException | InvalidKeyException e) {
	    	  System.out.println(e.getMessage()) ;
	         return false;
	      }
	   }
}
