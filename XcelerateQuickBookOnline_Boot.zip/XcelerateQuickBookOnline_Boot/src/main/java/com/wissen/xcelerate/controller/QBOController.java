package com.wissen.xcelerate.controller;

import com.wissen.xcelerate.model.RestCompDetails;
import com.wissen.xcelerate.pojo.QBOIntegration;
import com.wissen.xcelerate.repository.RestCompDetailsRepository;
import com.wissen.xcelerate.service.OAuth2PlatformClientFactory;
import java.util.List;
import javax.servlet.http.HttpSession;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.intuit.ipp.core.Context;
import com.intuit.ipp.core.ServiceType;
import com.intuit.ipp.data.CompanyInfo;
import com.intuit.ipp.data.Error;
import com.intuit.ipp.exception.FMSException;
import com.intuit.ipp.exception.InvalidTokenException;
import com.intuit.ipp.security.OAuth2Authorizer;
import com.intuit.ipp.services.DataService;
import com.intuit.ipp.services.QueryResult;
import com.intuit.ipp.util.Config;
import com.intuit.oauth2.client.OAuth2PlatformClient;
import com.intuit.oauth2.data.BearerTokenResponse;
import com.intuit.oauth2.exception.OAuthException;

/**
 * @author
 *
 */

@RestController
@RequestMapping(value = "/integration/qbo")
public class QBOController {
	
	@Autowired
	OAuth2PlatformClientFactory factory;
	
	@Autowired
	private RestCompDetailsRepository repository;

	
	private static final Logger logger = LogManager.getLogger(QBOController.class);
	
    /**
     * Sample QBO API call using OAuth2 tokens
     * 
     * @param session
     * @return
     */
	@ResponseBody
    @RequestMapping(value="/getCompanyInfo",method = RequestMethod.GET)
    public String callQBOCompanyInfo(HttpSession session) {
        QBOIntegration qbo=factory.getQBOIntegration();
        String failureMsg="Failed";
    	String url ="https://sandbox-quickbooks.api.intuit.com/v3/company";
    	int restCompId = 0;
    	String realmId=null;
    	String accessToken=null;
    	String refreshToken = null;
    	RestCompDetails details=null;
        try {
        	restCompId=qbo.getRestCompId();
    		details=repository.findByRestCompId(restCompId);
    		realmId= details.getQboRealmId();
    		if (StringUtils.isEmpty(realmId)) {
        		return new JSONObject().put("response","No realm ID.  QBO calls only work if the accounting scope was passed!").toString();
        	}
    		
        	accessToken = details.getQboAccessToken();
        	refreshToken=details.getQboRefreshToken();
        	// set custom config BASE_URL_QBO
        	Config.setProperty(Config.BASE_URL_QBO, url);

    		//get DataService
    		DataService service = getDataService(realmId, accessToken);
			
			// get all companyinfo
			String sql = "select * from companyinfo";
			QueryResult queryResult = service.executeQuery(sql);
			return processResponse(failureMsg, queryResult);
			
		}
	        /*
	         * Handle 401 status code - 
	         * If a 401 response is received, refresh tokens should be used to get a new access token,
	         * and the API call should be tried again.
	         */
	        catch (InvalidTokenException e) {			
				logger.error("Error while calling executeQuery :: " + e.getMessage());
				
				//refresh tokens
	        	logger.info("received 401 during companyinfo call, refreshing tokens now");
	        	OAuth2PlatformClient client  = qbo.getClient();
	           
	        	
				try {
					BearerTokenResponse bearerTokenResponse = client.refreshToken(refreshToken);
					String updatedAccessToken=bearerTokenResponse.getAccessToken();
					String updatedRefreshToken=bearerTokenResponse.getRefreshToken();
					RestCompDetails	company=repository.findByRestCompId(restCompId);
					company.setQboAccessToken(updatedAccessToken);
					company.setQboRefreshToken(updatedRefreshToken);
					repository.saveAndFlush(company);
		            //call company info again using new tokens
		            logger.info("calling companyinfo using new tokens");
		            DataService service = getDataService(realmId, updatedAccessToken);
					
					// get all companyinfo
					String sql = "select * from companyinfo";
					QueryResult queryResult = service.executeQuery(sql);
					return processResponse(failureMsg, queryResult);
					
				} catch (OAuthException e1) {
					logger.error("Error while calling bearer token :: " + e.getMessage());
					return new JSONObject().put("response",failureMsg).toString();
				} catch (FMSException e1) {
					logger.error("Error while calling company currency :: " + e.getMessage());
					return new JSONObject().put("response",failureMsg).toString();
				}
	            
			} catch (FMSException e) {
				List<Error> list = e.getErrorList();
				for(Error error2 : list) {
					logger.error("Error while calling executeQuery :: " + error2.getMessage());
				}
				 
				return new JSONObject().put("response",failureMsg).toString();
			}
		
    }

	private String processResponse(String failureMsg, QueryResult queryResult) {
		if (!queryResult.getEntities().isEmpty() && queryResult.getEntities().size() > 0) {
			CompanyInfo companyInfo = (CompanyInfo) queryResult.getEntities().get(0);
			logger.info("Companyinfo -> CompanyName: " + companyInfo.getCompanyName());
			ObjectMapper mapper = new ObjectMapper();
			try {
				String jsonInString = mapper.writeValueAsString(companyInfo);
				return jsonInString;
			} catch (JsonProcessingException e) {
				logger.error("Exception while getting company info ", e);
				return new JSONObject().put("response",failureMsg).toString();
			}
			
		}
		return failureMsg;
	}

	private DataService getDataService(String realmId, String accessToken) throws FMSException {
		
		//create oauth object
		OAuth2Authorizer oauth = new OAuth2Authorizer(accessToken);
		//create context QBO
		Context context = new Context(oauth, ServiceType.QBO, realmId);

		// create dataservice
		return new DataService(context);
	}

}
